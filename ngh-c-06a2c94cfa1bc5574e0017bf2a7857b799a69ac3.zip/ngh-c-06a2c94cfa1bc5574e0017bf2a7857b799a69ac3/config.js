const CONFIG = {
    introTitle: 'introTitle',
    introDesc: `introDesc`,
    btnIntro: 'btnIntro',
    title: 'title',
    desc: 'desc',
    btnYes: 'btnYes',
    btnNo: 'btnNo',
    question:'question',
    btnReply: 'btnReply',
    reply: 'reply',
    mess: 'mess',
    messDesc: 'messDesc',
    btnAccept: 'btnAccept',
    messLink: 'messLink', //link fb
    bgLink: 'https://huypham9205.github.io/tang-crush/img/bg.webp', //link ảnh nền
    iputBgLink: 'https://huypham9205.github.io/tang-crush/img/iput-bg.jpg', //link iputBgLink
    lookMeLink: 'https://huypham9205.github.io/tang-crush/img/lookMe.jpg', //link ảnh lookMe
    soundLink: 'https://huypham9205.github.io/tang-crush/sound/sound.mp3', //link nhac
    duckLink: 'https://huypham9205.github.io/tang-crush/sound/duck.mp3', //link aam thanh 1
    swishLink: 'https://huypham9205.github.io/tang-crush/sound/Swish1.mp3', //link swish
}
